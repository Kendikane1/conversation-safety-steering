"""Private replication controller. Importing this module never starts a worker."""
from pathlib import Path
from collections import Counter,defaultdict
from functools import lru_cache
from hashlib import sha256
from html import escape
from zipfile import ZipFile,ZIP_DEFLATED
from uuid import uuid4
import datetime,hmac,json,math,os,secrets,subprocess,sys,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import conversation_state as st
import pilot_data as pilot
import pilot_run
import pilot_science as science
import workflow

ARM={'U':'candidate','B_fit':'threshold_only','B_deployed':'deployed'}
POL=('allowed','disallowed')

FRAME={}  # W03H bind() installs exactly the frozen active cohort before any stage.

def require(ok,msg):
    if not ok:raise ValueError(msg)
def read(p):return st.read(p)
def sha(b):return sha256(b).hexdigest()
def identity(p):return sha(Path(p).read_bytes())
@lru_cache(maxsize=256)
def source_identity(p):return identity(p)
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(ns,n,x):return st.immutable(ns/n,x)
def checked(ns,n):
    p=ns/n
    require(p.exists(),'Missing '+n);return read(p)
def messages(f,branch,answer=None):
    return [*f['prefix'],dict(role='assistant',content=f['authored'] if answer is None else answer),dict(role='user',content=f['branches'][branch]['text'])]
def file_for(ns,kind,k):return ns/kind/(k+'.json')
def proof_for(ns,k,row):
    claim=file_for(ns,'claims',k)
    proof=dict(key=k,claim_sha256=identity(claim),body_sha256=st.digest(row),plan_sha256=source_identity(ns/'plan.json'))
    require(row['claim_sha256']==proof['claim_sha256'],'Different claim hash')
    if row.get('status') in ('ok','truncated'):
        info=read(claim);base=ns/'attempts'/info['attempt'];raw=row['raw']
        require(row['slot']==info['slot'] and raw['serialized_prompt_sha256']==info['prompt_sha256'] and
                raw['serialized_prompt_sha256']==row['prepared']['prompt']['serialized_prompt_sha256'],'Claim and measured prompt differ')
        proof.update(attempt=info['attempt'],load_sha256=source_identity(base/'load.json'),admission_sha256=source_identity(base/'admitted.json'))
    return proof

def store_record(ns,k,row):
    proof=proof_for(ns,k,row);blob='objects/'+proof['body_sha256']+'.json'
    save(ns,blob,row)
    seal=file_for(ns,'record-proofs',k);st.immutable(seal,proof)
    st.immutable(file_for(ns,'records',k),row)
    if row['status']=='runtime_error':
        save(ns,'stops/'+k+'.json',dict(key=k,record_sha256=proof['body_sha256'],reason=row.get('reason')))
    st.immutable(file_for(ns,'commits',k),dict(record_sha256=proof['body_sha256'],proof_sha256=identity(seal)))
    return row

def slot_record(ns,k,repair=False):
    claim=file_for(ns,'claims',k);p=file_for(ns,'records',k);seal=file_for(ns,'record-proofs',k);commit=file_for(ns,'commits',k)
    rejected=file_for(ns,'dispositions',k)
    if rejected.exists():
        row=read(rejected);require(row['claim_sha256']==identity(claim) and row['original_record']==(identity(p) if p.exists() else None),'Changed rejected record')
        return row
    if not p.exists() and not seal.exists() and not commit.exists():return {}
    proof=read(seal);h=proof['body_sha256'];require(len(h)==64 and all(c in '0123456789abcdef' for c in h),'Invalid record digest')
    blob=ns/'objects'/(h+'.json')
    if not p.is_file() or not commit.is_file():
        require(repair,'Pending publication: recover '+k)
        require(identity(blob)==h,'Unverified recovery bytes');row=read(blob)
        require(proof_for(ns,k,row)==proof,'Pending proof does not match source')
        if row['status'] in ('ok','truncated'):
            science.verify_row(row['raw'],row['effective_slot'],row['case'],row['prepared'],[])
            if row.get('decoded') is not None:require(row['decoded']==row['raw']['response'],'Writer decode differs')
        store_record(ns,k,row)
    require(read(commit)==dict(record_sha256=h,proof_sha256=identity(seal)) and identity(p)==h,'Record failed independent commit verification '+k)
    row=read(p);require(proof_for(ns,k,row)==proof,'Record source identities differ')
    return row

def prompt_for(ns,s):
    f=FRAME[s['family']]
    if s['phase']=='writers':return f['prefix'],None
    key='--'.join(['writers',s['family'],s['writer']])
    writer=slot_record(ns,key)
    if writer.get('status')!='ok' or not writer.get('decoded'):return None,'ineligible writer'
    if not checked(ns,'context-decisions.json').get(key+'--'+s['branch'],{}).get('usable'):return None,'unusable context'
    return messages(f,s['branch'],writer['decoded']),None

def worker(job,cache,emit,permit):
    import conversation_environment as env
    source_identity.cache_clear()
    if 'admission' not in cache:
        evidence={};old,adopted=env.worker_admission(job,evidence,True);cache['admission']=(evidence,old,adopted)
    evidence,old,adopted=cache['admission'];b=pilot.P['toolchain']
    require(evidence['environment_signature']==b['environment_signature'] and evidence['hardware_signature']==b['hardware_signature'] and evidence['versions']==b['baseline_distributions'] and identity(adopted['calibration']/'vectors.pt')==b['vector_sha256'] and old['calibration_checkpoint']==b['checkpoint_sha256'],'Scientific environment drift')
    if 'prefix' in job:
        import rep_service
        rep_service.publish_environment(Path(job['prefix']),env.gpu.v2.LOCAL/old['parent_package']/'cu130',Path(sys.prefix))
    sys.path.insert(0,str(adopted['root']/'src'))
    ns=Path(job['namespace']);phase=job['phase'];cap=checked(ns,'cap.json')['common_input_tokens']
    attempt=job['attempt'];folder=ns/'attempts'/attempt;st.immutable(folder/'admitted.json',evidence)
    slots=checked(ns,'plan.json');allowed=job['limit'];count=0
    require(phase in ('writers','crossed') and 1<=allowed<=(48 if phase=='writers' else 144),'Invalid phase allowance')
    require(not (ns/(phase+'-closed.json')).exists(),'Phase already closed')
    load_start=time.monotonic();reused='session' in cache
    if 'session' not in cache:cache['session']=science.PilotSession(adopted,old)
    session=cache['session'];st.immutable(folder/'load.json',dict(info=session.runtime['info'],vectors=session.before,reused=reused,seconds=time.monotonic()-load_start))
    phase_slots=[s for s in slots if s['phase']==phase]
    phase_keys={s['key'] for s in phase_slots}
    finished={p.stem for p in (ns/'records').glob('*.json') if p.stem in phase_keys}
    excluded={p.stem for p in (ns/'excluded').glob('*.json') if p.stem in phase_keys}
    by_family=defaultdict(list)
    for s in phase_slots:by_family[s['family']].append(s['key'])
    cache_by_prompt=defaultdict(list);loaded=set()
    try:
        for s in phase_slots:
            k=s['key']
            if k in finished:
                slot_record(ns,k);continue
            if k in excluded:continue
            require(not file_for(ns,'claims',k).exists(),'Unresolved claim '+k)
            if count>=allowed or time.time()-job['start']>=2700:break
            f=FRAME[s['family']];msgs,reason=prompt_for(ns,s)
            obs=pilot.measure(session.runtime['tokenizer'],msgs) if msgs else {}
            if phase=='crossed' and msgs:
                earlier=slot_record(ns,'writers--'+s['family']+'--'+s['writer'])['contexts'][s['branch']]
                require(obs==earlier,'Full prompt changed after the frozen context screen')
            if not reason and (not obs.get('proof') or obs['prompt']['input_tokens']>cap):reason='overflow' if obs.get('prompt') and obs['prompt']['input_tokens']>cap else 'invalid prompt'
            if reason:st.immutable(file_for(ns,'excluded',k),dict(reason=reason,observation=obs));continue
            cid='--'.join([s['family'],s['writer'] or 'fixed',s['branch'] or 'opening'])
            case=dict(case_id=cid,scenario_id=s['family'],category=f['stratum'],messages=msgs,history_type=phase,has_prior_refusal=None,prior_refusal_message_indices=[])
            slot=dict(case_id=cid,slot_id=k,input_cap=cap,max_new_tokens=1024,fixture=None,name=ARM[s['arm']],mode='conditional',alpha=.0625)
            prepared=dict(prompt=obs['prompt'],proof=obs['proof'])
            require(session.prepare_case(case,cap)==prepared,'Different serialization at generation')
            if s['family'] not in loaded:
                for previous in by_family[s['family']]:
                    if previous in finished:
                        row=slot_record(ns,previous)
                        if row.get('status') in ('ok','truncated'):
                            rr=row['raw'];cache_by_prompt[rr['serialized_prompt_sha256']].append(rr)
                loaded.add(s['family'])
            peers=cache_by_prompt[obs['prompt']['serialized_prompt_sha256']]
            claim=file_for(ns,'claims',k);claim.parent.mkdir(exist_ok=True)
            emit(dict(event='before_claim',slot=k,messages=msgs,phase=phase))
            permit(k)
            require(checked(ns,'lease.json')['owner']==job['owner'],'Lease changed before claim')
            publish_claim(claim,dict(attempt=attempt,slot=s,start=utc(),prompt_sha256=obs['prompt']['serialized_prompt_sha256'],reserved_tokens=1024,reserved_forwards=1025))
            count+=1;raw=None
            try:
                raw=session.generate(case,slot,prepared,peers[0]['scores'] if peers else None)
                require(raw['status'] in ('ok','truncated'),raw.get('error','generation failed'))
                science.verify_row(raw,slot,case,prepared,peers)
                for peer in peers:
                    require(peer['messages']==raw['messages'] and all(abs(raw['scores'][a]-v)<=1e-6 for a,v in peer['scores'].items()),'Same-prompt scores drifted')
                    if peer['gate']['decision']==raw['gate']['decision']:require(raw['generated_ids']==peer['generated_ids'] and raw['response']==peer['response'],'Same-route token stream drifted')
                session.close()
                decoded=pilot.decoded(session.runtime['tokenizer'],raw['generated_ids']) if phase=='writers' and raw['status']=='ok' else {}
                if decoded.get('assistant_message') is not None:require(decoded['assistant_message']==raw['response'],'Writer decoding drift')
                reply=decoded.get('assistant_message')
                context_observations={p:pilot.measure(session.runtime['tokenizer'],messages(f,p,reply)) for p in POL} if phase=='writers' and reply else {}
                result=dict(status=raw['status'],raw=raw,decoded=reply,decode_proof=decoded,contexts=context_observations)
            except Exception as exc:
                result=dict(status='runtime_error',reason=str(exc),raw=raw,consumption_unknown=True)
            store_record(ns,k,dict(result,slot=s,claim_sha256=identity(claim),completed=utc(),effective_slot=slot,case=case,prepared=prepared))
            if result['status'] in ('ok','truncated'):peers.append(raw)
            output=raw or {}
            emit(dict(slot=k,attempt=attempt,status=result['status'],messages=msgs,writer=s['writer'],responder=s['arm'],branch=s['branch'],scores=output.get('scores'),response=output.get('response'),generated_tokens=output.get('generated_tokens'),input_tokens=output.get('input_tokens'),gate=output.get('gate'),seconds=output.get('seconds'),claimed_in_invocation=count))
            if result['status']=='runtime_error':cache.pop('session',None);break
    finally:session.close()
    return dict(claimed_now=count,phase=phase)

def publish_claim(path,obj):
    # Any file at this exclusive name reserves the complete slot, even after a torn write.
    data=st.encoded(obj)
    with path.open('xb') as out:
        out.write(data);out.flush();os.fsync(out.fileno())
    require(path.read_bytes()==data,'Claim readback failed')

def pending_stops(ns):
    errors=[p for p in (ns/'stops').glob('*.json')]
    return {str(p.relative_to(ns)):identity(p) for p in errors if not (ns/'clearances'/(identity(p)+'.json')).exists()}

def clear_stops(ns,digests,reference,diagnosis):
    current=pending_stops(ns)
    require(current and current==digests and reference.strip() and diagnosis.strip(),'Explicit current stop identities, central reference and diagnosis required')
    for name,h in current.items():save(ns,'clearances/'+h+'.json',dict(stop=name,identity=h,reference=reference,diagnosis=diagnosis))

def dispatch(private,ns,phase,limit,owner,reference,credit):
    import rep_service
    return rep_service.request(private,ns,phase,limit,owner,reference,credit)

def close_phase(ns,phase,status):
    slots=[s for s in checked(ns,'plan.json') if s['phase']==phase];rows={}
    for s in slots:
        k=s['key'];r=slot_record(ns,k);claim=file_for(ns,'claims',k);skip=file_for(ns,'excluded',k)
        require(r or not claim.exists(),'Unresolved claim '+k)
        rows[k]=dict(record=identity(file_for(ns,'records',k)) if file_for(ns,'records',k).exists() else None,exclusion=identity(skip) if skip.exists() else None,disposition=identity(file_for(ns,'dispositions',k)) if file_for(ns,'dispositions',k).exists() else None)
    require(status in ('complete','stopped') and (status=='stopped' or all(any(v.values()) for v in rows.values())),'Unstarted slots require stopped disposition')
    path=phase+'-closed.json'
    if (ns/path).exists():
        old=checked(ns,path);require(old['rows']==rows and old['status']==status,'Closed phase changed');return identity(ns/path)
    return save(ns,path,dict(status=status,rows=rows,closed=utc()))

def recover(ns,disposition=None,repair=False):
    unresolved={};repaired=[]
    for claim in sorted((ns/'claims').glob('*.json')):
        k=claim.stem
        try:
            was_pending=not file_for(ns,'commits',k).exists()
            row=slot_record(ns,k,repair=repair)
            if not row:unresolved[k]='claim without proved result'
            elif was_pending and file_for(ns,'commits',k).exists():repaired.append(k)
        except (OSError,ValueError,KeyError,TypeError) as exc:unresolved[k]=str(exc)
    if disposition:
        k,reason=disposition;require(k in unresolved and reason.strip(),'Wrong unresolved slot')
        slot=next(s for s in checked(ns,'plan.json') if s['key']==k);claim=file_for(ns,'claims',k);p=file_for(ns,'records',k)
        row=dict(status='runtime_error',slot=slot,claim_sha256=identity(claim),original_record=identity(p) if p.exists() else None,reason=reason,consumption_unknown=True,reserved_tokens=1024,reserved_forwards=1025)
        if any(file_for(ns,kind,k).exists() for kind in ('records','record-proofs','commits')):
            st.immutable(file_for(ns,'dispositions',k),row);save(ns,'stops/'+k+'-rejected.json',row)
        else:store_record(ns,k,row)
        del unresolved[k]
    return dict(outstanding=list(unresolved),reasons=unresolved,repaired=repaired,claimed=len(list((ns/'claims').glob('*.json'))))
