"""Reconstruct accepted W01S/W01L namespaces in VM storage, once per runtime."""
from contextlib import ExitStack
from pathlib import Path
from zipfile import ZipFile
import json,os,time
import conversation_state as st
HERE=Path(__file__).resolve().parent

def mirror(private,root):
    root.mkdir(parents=True,exist_ok=True)
    short=st.read(HERE/'w01_length_v1.json');long=st.read(HERE/'w01_conversation_v1.json')
    targets={'strength-results':('w01s',short['parent_strength_package'],[short[k] for k in ('parent_final','parent_selection','parent_sweep')]),'length-results':('w01l',long['parent_length_package'],[long[k] for k in ('parent_final','parent_confirmation','parent_selection','parent_comparison')])}
    for name,(prefix,package,hashes) in targets.items():
        dst=root/name/package;src=private/name/package; marker=dst/'verified.json'
        if marker.exists():
            st.require(st.read(marker)['receipts']==hashes,'Foreign cached parent');continue
        dst.mkdir(parents=True,exist_ok=True);expected={};receipts={};done=0;size=0
        with ExitStack() as stack:
            archives=[]
            fname=f'{prefix}-final-{hashes[0]}.zip'
            remote=next((p for p in (src/'exports'/fname,private/fname) if p.is_file()),None)
            if remote:
                local=dst/fname
                if not local.exists():
                    total=remote.stat().st_size;size_read=0
                    print('Caching',fname,total,'bytes',flush=True)
                    with remote.open('rb') as source,local.with_suffix('.partial').open('wb') as out:
                        while chunk:=source.read(4*1024*1024):
                            out.write(chunk);size_read+=len(chunk);print('Cache copy',size_read,'/',total,'bytes',flush=True)
                    local.with_suffix('.partial').replace(local)
                archives.append(stack.enter_context(ZipFile(local)))
            for h in hashes:
                member='outer-receipt.json' if h==hashes[0] else 'parent-receipts/'+h+'.json'
                raw=archives[0].read(member) if archives and member in archives[0].NameToInfo else (src/'receipts'/(h+'.json')).read_bytes()
                st.require(st.sha(raw)==h,'Historical receipt changed');receipts[h]=raw
                for n,v in json.loads(raw)['files'].items():
                    st.require(not Path(n).is_absolute() and '..' not in Path(n).parts and expected.setdefault(n,v)==v,'Historical file conflict')
            last=time.monotonic()
            for n,v in expected.items():
                target=dst/n
                if target.is_file() and st.sha(target.read_bytes())==v:data=None;size+=target.stat().st_size
                else:
                    archive=next((z for z in archives if n in z.NameToInfo),None)
                    data=archive.read(n) if archive else (src/n).read_bytes()
                    st.require(st.sha(data)==v,'Historical member differs '+n);st.atomic(target,data);size+=len(data)
                done+=1
                if done%200==0 or time.monotonic()-last>10:
                    print(name,done,'/',len(expected),'verified files;',size,'bytes',flush=True);last=time.monotonic()
            for h,raw in receipts.items():st.immutable(dst/'receipts'/(h+'.json'),raw)
        st.immutable(marker,dict(receipts=hashes,files=done,bytes=size));print(name,'verified',done,size,flush=True)
    return root

from contextlib import contextmanager
from unittest.mock import patch

@contextmanager
def local_history(private,cache):
    """Only the two frozen history namespaces come from cache; gpu.adopt receives the real Path."""
    import conversation_environment as env
    import length_environment as length
    frozen_conversation, frozen_length, frozen_strength=env.adopt,length.adopt,length.adopt_strength
    class HistoricalLookup:
        def __truediv__(self,component):
            return (cache if component=='length-results' else private)/component
    with patch.object(env,'adopt',lambda path,p: frozen_conversation(HistoricalLookup(),p)), \
         patch.object(length,'adopt',lambda path,p: frozen_length(private,p)), \
         patch.object(length,'adopt_strength',lambda path,p:frozen_strength(cache,p)):
        yield
