"""Model-free eligibility, roster, and family-level analysis for the separate eight-family study."""
import hashlib,itertools,json,statistics
from pathlib import Path
from zipfile import ZipFile
ROOT=Path(__file__).resolve().parent
ARMS=('U','B_fit','B_deployed')
POLICIES=('allowed','disallowed')
def sha(data):return hashlib.sha256(data).hexdigest()
def check(ok,message):
    if not ok:raise ValueError(message)
def roster():
    import replication as r
    return list(r.FRAME)
def plan():
    families=roster()
    return dict(stage='W03H-heldout',writers=[f'{f}--{w}' for f in families for w in ARMS],
        contexts=[f'{f}--{w}--{b}' for f,w,b in itertools.product(families,ARMS,POLICIES)],
        terminals=[f'{f}--{w}--{b}--{a}' for f,w,b,a in itertools.product(families,ARMS,POLICIES,ARMS)])
def mean(xs):return statistics.fmean(xs) if xs else None
def summarize(ledger):
    planned=plan(); rows=ledger['terminal']
    check(set(rows)==set(planned['terminals']) and set(ledger['contexts'])==set(planned['contexts']),'All 144 terminal reservations and 48 contexts required')
    for k,c in ledger['contexts'].items():
        check(type(c['eligible']) is bool and isinstance(c['reason'],str) and c['reason'].strip(),'Invalid context eligibility')
    for k,r in rows.items():
        _,_,b,_=k.split('--')
        check(r['status'] in ('natural','truncated','unreviewed','unknown','technical','unstarted','excluded','quality_excluded'),'Unknown terminal disposition')
        if r['status']=='natural':
            check(ledger['contexts'][k.rsplit('--',1)[0]]['eligible'] and type(r['harm']) is bool and (b!='allowed' or all(type(r[k]) is bool for k in ('useful','overrefusal'))),'Unreviewable result')
    def value(f,w,b,a,m):
        row=rows['--'.join([f,w,b,a])]
        return int(row[m]) if row['status']=='natural' else None
    def group(indices,make_pair,branch,metric):
        per={};low=[];high=[];changes={k:[] for k in ('increased','decreased','unchanged','unobserved')}
        for f in roster():
            ds=[]
            for i in indices:
                (lw,la),(rw,ra)=make_pair(i)
                x=value(f,lw,branch,la,metric);y=value(f,rw,branch,ra,metric)
                pair_id='--'.join([f,str(lw),branch,la+'-vs-'+str(rw)+'-'+ra])
                if x is not None and y is not None:
                    ds.append(x-y);changes['increased' if x>y else 'decreased' if x<y else 'unchanged'].append(pair_id)
                else:changes['unobserved'].append(pair_id)
                low.append((x if x is not None else 0)-(y if y is not None else 1))
                high.append((x if x is not None else 1)-(y if y is not None else 0))
            per[f]=dict(eligible=len(ds),planned=len(indices),difference=mean(ds))
        complete=[r['difference'] for r in per.values() if r['difference'] is not None]
        return dict(families=per,represented=len(complete),all_families=8,available_paired=mean(complete),
            reserved_bounds=[mean(low),mean(high)],reserved_slots=len(low),paired_changes=changes)
    out={}
    for branch,metric in [('allowed','useful'),('allowed','overrefusal'),('allowed','harm'),('disallowed','harm')]:
        target=out[branch+'/'+metric]={}
        for other in ARMS[1:]:
            target['responder/U-minus-'+other]=group(ARMS,lambda w:((w,'U'),(w,other)),branch,metric)
            for writer in ARMS:
                target[f'responder/U-minus-{other}/writer/{writer}']=group([writer],lambda w:((w,'U'),(w,other)),branch,metric)
        for l,r in itertools.combinations(ARMS,2):
            target['diagonal/'+l+'-minus-'+r]=group([None],lambda _:((l,l),(r,r)),branch,metric)
            for a in ARMS:
                target[f'writer/{l}-minus-{r}/responder/{a}']=group([None],lambda _:((l,a),(r,a)),branch,metric)
    from collections import Counter
    return dict(planned=dict(writers=24,contexts=48,terminal=144),contrasts=out,
        context_eligibility={w:dict(Counter(str(ledger['contexts'][k]['eligible']) for k in planned['contexts'] if k.split('--')[1]==w)) for w in ARMS},
        loss_reasons=dict(Counter(v['reason'] for v in ledger['contexts'].values() if not v['eligible'])),
        terminal_dispositions=dict(Counter(r['status'] for r in rows.values())))
