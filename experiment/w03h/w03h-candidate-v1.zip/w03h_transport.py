import json,sys,subprocess,secrets
from zipfile import ZipFile
import hashlib
import json
import os
import re
import stat
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch

def component(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,199}', value):
        raise ValueError('Use a single ordinary basename without path separators')
    return value

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def ordinary_dir(stack, path, parent=None):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
    stack.callback(os.close, fd)
    return fd

def ordinary_file(parent, name):
    fd = os.open(component(name), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
    with os.fdopen(fd, 'rb') as stream:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise ValueError('Expected an ordinary file')
        return stream.read()

def unique_fields(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate manifest entry')
        result[key] = value
    return result

def checked_files(private_root, batch, manifest_sha, multiple):
    if not re.fullmatch(r'[0-9a-f]{64}', manifest_sha):
        raise ValueError('Enter the sender-verified lowercase SHA-256 of manifest.json')
    with ExitStack() as stack:
        root = ordinary_dir(stack, private_root)
        inbox = ordinary_dir(stack, 'generated-feasibility-inbox', root)
        folder = ordinary_dir(stack, component(batch), inbox)
        raw = ordinary_file(folder, 'manifest.json')
        if sha256(raw) != manifest_sha:
            raise ValueError('Manifest SHA-256 differs')
        files = json.loads(raw, object_pairs_hook=unique_fields)
        if not isinstance(files, dict) or not files or len(files) > 768 or (not multiple and len(files) != 1):
            raise ValueError('Supply exactly one JSON file for a single import, or a nonempty packet manifest for merge')
        if len({name.casefold() for name in files}) != len(files):
            raise ValueError('Ambiguous filenames')
        entries = {}
        print('Private import manifest', batch, manifest_sha, flush=True)
        for name, expected in files.items():
            component(name)
            if name.casefold() == 'manifest.json' or not name.endswith('.json') or not isinstance(expected, str) or not re.fullmatch(r'[0-9a-f]{64}', expected):
                raise ValueError('Invalid JSON filename or SHA-256')
            data = ordinary_file(folder, name)
            if sha256(data) != expected:
                raise ValueError('File SHA-256 differs: ' + name)
            entries[name] = data
            print(name, expected, len(data), 'bytes', flush=True)
        return entries


def stream_controller(command,frontend_ack,on_event=None,environ=None):
    """The live notebook owns both ends of the control exchange with its child."""
    with subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,env=environ) as controller:
        try:
            for line in controller.stdout:
                if line.startswith('W03R_PRECLAIM '):
                    challenge=json.loads(line.removeprefix('W03R_PRECLAIM '))
                    if frontend_ack(challenge['nonce'])!=challenge['nonce']:raise ConnectionError('Attached notebook did not acknowledge slot')
                    controller.stdin.write(json.dumps(challenge)+'\n');controller.stdin.flush()
                elif line.startswith('W03R_EVENT '):
                    event=json.loads(line.removeprefix('W03R_EVENT '));answer=event.pop('response',None)
                    print(json.dumps(event,ensure_ascii=False),flush=True)
                    if isinstance(answer,str):print(answer,flush=True)
                    if on_event:on_event(event,answer,controller)
                else:print(line,end='',flush=True)
        except BaseException:
            controller.terminate()
            try:controller.wait(timeout=10)
            except subprocess.TimeoutExpired:controller.kill();controller.wait()
            raise
        finally:controller.stdin.close()
        if controller.wait():raise RuntimeError('Controller stopped. Inspect recovery and durable claims.')

def preclaim(key):
    challenge=dict(slot=key,nonce=secrets.token_hex(24))
    print('W03R_PRECLAIM '+json.dumps(challenge),flush=True)
    line=sys.stdin.readline()
    if not line or json.loads(line)!=challenge:
        raise ConnectionError('No attached notebook acknowledgment; slot was never claimed')

def prior_failure(private):
    outer='ac78114915660dd11ebdb148b62dc7538e628f8c5767a28b9fa7ccd1e7c76773'
    archive='d90889f175902adc1c007ee57f0e156989b6b5cbc073b94c807ee652a6bbbbf7'
    pkg='b4e342a11a26826b65f643d051a95bdc86137d6e2f48e48886252c55eb6c506b'
    name='w03c-final-'+outer+'.zip'
    path=private/'length-coverage-results'/pkg/'exports'/name
    if not path.is_file():path=private/name
    if sha256(path.read_bytes())!=archive:raise ValueError('Wrong W03C final archive')
    with ZipFile(path) as z:
        raw=z.read('outer-receipt.json');r=json.loads(raw)
        if sha256(raw)!=outer:raise ValueError('Wrong W03C final receipt')
        dec=json.loads(z.read(r['paths']['decision']))
        if dec['coverage_nominee']!=1024 or dec['semantic_pass'] or dec['disposition']!='replication design needs review':
            raise ValueError('Prior study outcome differs')
    return dict(archive=archive,outer=outer,cap=1024,semantic_pass=False,selection_weight=0)
