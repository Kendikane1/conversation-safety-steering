"""Fixed-denominator tables and an offline conversation selector; no execution."""
import json
from html import escape
from collections import defaultdict,Counter
import replication as r
import w03h_context as context
import report

def publish(ns,cohort):
    context.verify(ns)
    decisions=r.checked(ns,'context-decisions.json')
    if cohort=='pilot':
        data=r.checked(ns,'pilot-decision.json');extra={};score=None
    else:
        data,extra=report.ledger(ns);score=r.workflow.summarize(data)
        r.save(ns,'analysis/ledger.json',data);r.save(ns,'analysis/contrasts.json',score)
    conversations=[];histories=defaultdict(set)
    labels={}
    if cohort=='heldout':labels=r.checked(ns,'review/crossed/labels.json')['slots']
    for s in r.checked(ns,'plan.json'):
        row=r.slot_record(ns,s['key']);raw=row.get('raw') or {}
        if s['phase']=='writers' and row.get('decoded'):histories[s['family']].add(r.sha(row['decoded'].encode()))
        conversations.append(dict(slot=s['key'],family=s['family'],writer=s['arm'] if s['phase']=='writers' else s['writer'],branch=s['branch'] or 'opening',responder=s['arm'] if s['phase']=='crossed' else 'writer',messages=raw.get('messages') or row.get('case',{}).get('messages'),answer=raw.get('response'),status=row.get('status','excluded' if r.file_for(ns,'excluded',s['key']).exists() else 'unstarted'),scores=raw.get('scores'),gate=raw.get('gate'),input_tokens=raw.get('input_tokens'),generated_tokens=raw.get('generated_tokens'),label=labels.get(s['key'])))
    for k,c in r.checked(ns,'context-observations.json').items():
        conversations.append(dict(slot=k,family=c['family'],writer=c['writer'],branch=c['branch'],responder='context',messages=c['observation'].get('messages'),answer=None,eligibility=decisions[k]))
    completeness={}
    if cohort=='heldout':
        for f in r.FRAME:
            context_complete=all(data['contexts']['--'.join([f,w,b])]['eligible'] for w in r.ARM for b in r.POL)
            complete_labels=all(data['terminal']['--'.join([f,w,b,a])]['status']=='natural' for w in r.ARM for b in r.POL for a in r.ARM)
            by_branch={b:{other:sum(data['terminal']['--'.join([f,w,b,a])]['status']=='natural' for w in r.ARM for a in ('U',other))==6 for other in ('B_fit','B_deployed')} for b in r.POL}
            completeness[f]=dict(all_contexts=context_complete,all_terminal_judgments=complete_labels,complete_family=context_complete and complete_labels,all_writer_pair_support=by_branch)
    diagnostics=dict(extra,interpretation='Exploratory survivor-selected available-pair responder contrasts: common eligible writer-history/branch pairs, average writers within each family, then weight represented families equally. Bounds assume a binary endpoint for every reserved context, including structural exclusions; they are not observed effects on interpretable tasks.',distinct_history_counts={f:len(histories[f]) for f in r.FRAME},independent_families=len(r.FRAME),completeness=completeness,context_decisions=decisions,observations=conversations)
    diagnostics['context_review_returns']={role:r.read(ns/('context/'+role+'.json')) for role in ('reader1','reader2','adjudicator') if (ns/('context/'+role+'.json')).exists()}
    # Preserve raw concern-bearing labels even for excluded-quality/truncated answers.
    diagnostics['settled_observed_harm_slots']=[x['slot'] for x in conversations if (x.get('label') or {}).get('decision')=='settled' and x['label'].get('harm') is True] if labels else []
    r.save(ns,'analysis/diagnostics.json',diagnostics)
    title=('SYNTHETIC REHEARSAL · ' if r.checked(ns,'cap.json')['scope']=='synthetic' else '')+'W03H '+cohort
    html='<!doctype html><meta charset="utf-8"><title>'+escape(title)+'</title><style>body{font:16px system-ui;max-width:1100px;margin:2em auto}pre{white-space:pre-wrap;overflow-wrap:anywhere}select{margin:8px}</style><h1>'+escape(title)+'</h1><p>'+escape(diagnostics['interpretation'])+'</p>'
    if score:
        html+='<table border="1" cellpadding="8"><tr><th>Outcome</th><th>Contrast</th><th>Family-weighted difference</th><th>Families</th><th>All-reservation bounds</th><th>Changed and missing pairs (IDs)</th></tr>'
        for outcome,cs in score['contrasts'].items():
            for name,v in cs.items():
                if name.startswith('responder/') and '/writer/' not in name:html+='<tr>'+''.join('<td>'+escape(str(x))+'</td>' for x in (outcome,name,v['available_paired'],v['represented'],v['reserved_bounds'], {k:dict(count=len(ids),ids=ids) for k,ids in v['paired_changes'].items()}))+'</tr>'
        html+='</table>'
    else:html+='<pre>'+escape(json.dumps(data,indent=2))+'</pre>'
    html+='<h2>Conversation viewer</h2><div id="controls"></div><div id="results"></div><details><summary>All denominators, exclusions, concerns and stratified contrasts</summary><pre>'+escape(json.dumps(dict(diagnostics=diagnostics,contrasts=score),indent=2,ensure_ascii=False))+'</pre></details>'
    payload=json.dumps(conversations,ensure_ascii=False).replace('<','\\u003c').replace('&','\\u0026')
    html+='<script>const rows='+payload+'''; const keys=['family','writer','branch','responder']; const controls=document.getElementById('controls');
const selects={}; for(const k of keys){const label=document.createElement('label');label.textContent=k;const s=document.createElement('select');s.append(new Option('All',''));for(const v of [...new Set(rows.map(r=>r[k]))].sort())s.append(new Option(v,v));label.append(s);controls.append(label);selects[k]=s;s.onchange=render;}
function render(){const target=document.getElementById('results');target.replaceChildren();for(const r of rows.filter(r=>keys.every(k=>!selects[k].value||r[k]===selects[k].value))){const d=document.createElement('details');const sum=document.createElement('summary');sum.textContent=r.slot;const p=document.createElement('pre');p.textContent=JSON.stringify(r,null,2);d.append(sum,p);target.append(d);}}render();</script>'''
    r.save(ns,'analysis/viewer.html',html.encode());return ns/'analysis/viewer.html'
