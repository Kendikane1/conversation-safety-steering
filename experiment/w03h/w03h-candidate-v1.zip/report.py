"""Normalize the frozen label join, retain observed text and compute family effects."""
import json
from html import escape
from collections import Counter,defaultdict
import replication as r
import reviews
def ledger(ns):
    verdict=reviews.load(ns,'crossed','labels');labels=verdict['slots']
    contexts={k.removeprefix('writers--'):dict(eligible=v['usable'],reason=v['reason'],prior_refusal=v['prior_refusal']) for k,v in r.checked(ns,'context-decisions.json').items()}
    terminal={};visible=[];duplicates=defaultdict(list);conversations=[]
    for s in r.checked(ns,'plan.json'):
        k=s['key'];row=r.slot_record(ns,k);raw=row.get('raw') or {};label=labels.get(k,{})
        conversations.append(dict(slot=k,phase=s['phase'],messages=raw.get('messages'),answer=raw.get('response'),gate=raw.get('gate'),tokens=raw.get('generated_tokens'),status=row.get('status','excluded or unstarted'),reader_label=label))
        if s['phase']=='writers':
            if row.get('decoded'):duplicates[(s['family'],r.sha(row['decoded'].encode()))].append(s['arm'])
            continue
        status=row.get('status')
        if r.file_for(ns,'excluded',k).is_file() or not contexts[k.removeprefix('crossed--').rsplit('--',1)[0]]['eligible']:out='excluded'
        elif not status:out='unstarted'
        elif row.get('consumption_unknown'):out='unknown'
        elif status=='truncated':out='truncated'
        elif status!='ok':out='technical'
        elif label.get('decision')!='settled':out='unreviewed'
        elif label.get('coherent') is not True or label.get('degenerate') is not False or label.get('natural_finish') is not True or raw.get('finish_reason')!='eos_token':out='quality_excluded'
        else:out='natural'
        terminal[k.removeprefix('crossed--')]=dict(status=out,**{f:label.get(f) for f in ('harm','useful','overrefusal')})
        if out!='natural' and label.get('harm') is True:visible.append(k)
    result=dict(contexts=contexts,terminal=terminal)
    earlier={}
    for f in r.FRAME:
        for w in r.ARM:
            pair=[contexts['--'.join([f,w,b])]['prior_refusal'] for b in r.POL]
            known={v for v in pair if type(v) is bool}
            earlier[f+'--'+w]=dict(prior_refusal=next(iter(known)) if len(known)==1 else None,by_branch=pair,disputed=len(known)>1)
    return result,dict(prior_refusal_by_writer=earlier,visible_excluded_concerns=visible,duplicate_writer_histories=[dict(family=f,answer_sha256=h,writers=arms) for (f,h),arms in duplicates.items() if len(arms)>1],observations=conversations)
def publish(ns):
    data,extra=ledger(ns);r.save(ns,'analysis/ledger.json',data);r.save(ns,'analysis/diagnostics.json',extra)
    score=r.workflow.summarize(data);r.save(ns,'analysis/contrasts.json',score)
    r.save(ns,'analysis/bindings.json',{n:r.identity(ns/n) for n in ['release.json','cap.json','writers-closed.json','context-freeze.json','crossed-closed.json','review/crossed/labels.json','analysis/ledger.json','analysis/diagnostics.json','analysis/contrasts.json']})
    label='SYNTHETIC REHEARSAL · ' if r.checked(ns,'cap.json')['scope']=='synthetic' else ''
    html='<article><h2>'+label+'Held-out generated-history efficacy</h2><p>8 families · 24 writers · 48 contexts · 144 reserved terminal slots.</p>'
    def show(obj):return '<pre style="white-space:pre-wrap">'+escape(json.dumps(obj,ensure_ascii=False,indent=2))+'</pre>'
    for m,cs in score['contrasts'].items():
        html+='<h3>'+escape(m)+'</h3>'+show({k:{f:v[f] for f in ('available_paired','reserved_bounds','represented','reserved_slots')} for k,v in cs.items() if k.startswith('responder/') and '/writer/' not in k})
        html+='<details><summary>All paired contrasts and family denominators</summary>'+show(cs)+'</details>'
    html+='<details><summary>Eligibility and observed concerns</summary>'+show(dict(contexts=data['contexts'],visible=extra['visible_excluded_concerns'],duplicates=extra['duplicate_writer_histories'],prior_refusals=extra['prior_refusal_by_writer']))+'</details>'
    for item in extra['observations']:html+='<details><summary>'+escape(item['slot'])+'</summary>'+show(item)+'</details>'
    r.save(ns,'analysis/report.html',(html+'</article>').encode())
    return ns/'analysis/report.html'
