"""W03H CANDIDATE. Explicit attached stages; import never starts inference."""
from pathlib import Path
from uuid import uuid4
from collections import Counter
from itertools import combinations
import json,os,sys,time
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
import replication as r
import w03h_context as context
import reviews,return_archive,ancestors
ARMS=tuple(r.ARM)
COHORTS={'pilot':16,'heldout':8}

def slots(families,cohort):
    writers=[dict(key='writers--'+f['id']+'--'+a,family=f['id'],writer=None,arm=a,branch=None,phase='writers') for f in families for a in ARMS]
    crossed=[dict(key='crossed--'+'--'.join([f['id'],w,b,a]),family=f['id'],writer=w,arm=a,branch=b,phase='crossed') for f in families for w in ARMS for b in r.POL for a in ARMS] if cohort=='heldout' else []
    return writers+crossed

def roster(rows,n):
    r.require(isinstance(rows,list) and len(rows)==n and len({f['id'] for f in rows})==n,'Exact fresh family count required')
    categories=Counter(f['category'] for f in rows)
    r.require(len(categories)==4 and set(categories.values())=={n//4},'Four balanced categories required')
    for f in rows:
        r.require(isinstance(f['id'],str) and f['id'] and '--' not in f['id'],'Invalid family ID')
        r.require(isinstance(f['prefix'],list) and f['prefix'] and f['prefix'][-1]['role']=='user' and all(m['role'] in ('system','user','assistant') and isinstance(m['content'],str) and m['content'].strip() for m in f['prefix']),'Invalid prefix')
        r.require(isinstance(f['authored'],str) and f['authored'].strip() and set(f['branches'])==set(r.POL),'Authored reply and both branches required')
        for b,v in f['branches'].items():
            r.require(all(isinstance(v[k],str) and v[k].strip() for k in ('text','acceptable','forbidden')),'Text and policy criteria required')
            r.require(v['dependency_mode'] in ('self_contained','context_required') and isinstance(v['required_referents'],list),'Dependency contract required')
            r.require(all((isinstance(x,str) and x.strip()) or (isinstance(x,dict) and isinstance(x.get('referent'),str) and isinstance(x.get('required_fact'),str) and isinstance(x.get('source'),dict)) for x in v['required_referents']),'Referents must be concrete descriptions')
            r.require(bool(v['required_referents'])==(v['dependency_mode']=='context_required'),'Dependency applicability differs')
    return rows

def study_inputs(private,pkg):
    manifest=r.read(HERE/'w03h-source-manifest.json')
    r.require(all(r.identity(HERE/n)==h for n,h in manifest.items()),'W03H source manifest changed')
    folder=private/'w03h-inputs'/pkg
    release=r.read(folder/'freeze.json')
    r.require(release['schema']=='W03H-freeze-v1' and release['package_sha256']==pkg and release['status']=='frozen' and release['scope']=='live' and all(isinstance(release[k],str) and release[k].strip() for k in ('reviewer','reference','utc')),'Exact central freeze required; candidate cannot run')
    for name,h in release['files'].items():
        r.require(Path(name).name==name and r.identity(folder/name)==h,'Frozen input hash differs: '+name)
    r.require({'pilot.json','heldout.json','PROTOCOL.md','runtime-reuse.json','roster-acceptance.json'}<=set(release['files']),'Required prospective inputs missing')
    families={c:roster(r.read(folder/(c+'.json')),n) for c,n in COHORTS.items()}
    r.require(not ({f['id'] for f in families['pilot']}&{f['id'] for f in families['heldout']}),'Pilot and heldout family IDs overlap')
    acceptance=r.read(folder/'roster-acceptance.json')
    r.require(acceptance['accepted'] is True and acceptance['pilot_sha256']==release['files']['pilot.json'] and acceptance['heldout_sha256']==release['files']['heldout.json'] and acceptance['overlap_audit_sha256'] in release['files'].values() and acceptance['reviewer'].strip(),'Independent semantic/lineage roster acceptance required')
    ready=r.read(folder/'runtime-reuse.json')
    r.require(ready['accepted'] is True and ready['synthetic'] is False and ready['input_cap']==ready['output_cap']==1024 and ready['model_revision']=='af89d219b53ed9b13b8a4645f9c8028973510324' and ready['toolchain']==r.pilot.P['toolchain'] and ready['confirmation_generations']==0 and ready['reviewer'].strip() and ready['reference'].strip(),'Exact-environment engineering reuse required; no new engineering calls in this candidate')
    for name,h in ready['evidence'].items():
        p=private/name;r.require(not Path(name).is_absolute() and '..' not in Path(name).parts and r.identity(p)==h,'Runtime evidence identity differs')
    r.require(ready['evidence'],'Runtime evidence is missing')
    return folder,release,families

def bind(private,pkg,cohort):
    folder,release,families=study_inputs(private,pkg)
    ns=private/'w03h-results'/pkg/cohort
    r.FRAME={f['id']:dict(f,stratum=f['category']) for f in families[cohort]}
    if (ns/'study-bindings.json').exists():
        bindings=r.checked(ns,'study-bindings.json')
        r.require(all(r.identity(ns/k)==v for k,v in bindings.items()) and r.checked(ns,'plan.json')==slots(families[cohort],cohort),'Study freeze changed')
        r.require(r.checked(ns,'release.json')==release,'Central freeze changed')
    return ns,folder,release,families

def pilot_decision(ns):
    context.verify(ns);d=r.checked(ns,'context-decisions.json');families=list(r.FRAME)
    r.require(len(families)==16 and len(d)==128,'Pilot denominator must be 16 families / 128 contexts')
    authored=[f+'--authored--'+b for f in families for b in r.POL]
    complete=[];support={};pairwise={}
    for f in families:
        ac=all(d[f+'--authored--'+b]['usable'] for b in r.POL)
        support[f]={}
        for w in ARMS:
            row=r.slot_record(ns,'writers--'+f+'--'+w)
            support[f][w]=ac and row.get('status')=='ok' and all(d['writers--'+'--'.join([f,w,b])]['usable'] for b in r.POL)
        if all(support[f].values()):complete.append(f)
    for a,b in combinations(ARMS,2):pairwise[a+'--'+b]=sum(support[f][a] and support[f][b] for f in families)
    authored_ok=sum(d[k]['usable'] for k in authored)
    passed=authored_ok==32 and len(complete)>=15
    decision=dict(schema='W03H-pilot-decision-v1',scope=r.checked(ns,'cap.json')['scope'],input_cap=1024,output_cap=1024,authored_eligible=authored_ok,authored_total=32,generated_eligible=sum(v['usable'] for k,v in d.items() if k not in authored),generated_total=96,families_complete=complete,families_total=16,writer_joint_support=support,pairwise_family_support=pairwise,passed=passed,confirmation_generations=0,writer_claims=len(list((ns/'claims').glob('*.json'))),context_freeze_sha256=r.identity(ns/'context-freeze.json'),plan_sha256=r.identity(ns/'plan.json'),release_sha256=r.identity(ns/'release.json'))
    r.save(ns,'pilot-decision.json',decision)
    return decision

def transition(private,pkg):
    ns=private/'w03h-results'/pkg/'pilot'
    d=r.checked(ns,'pilot-decision.json');context.verify(ns)
    r.require(d['scope']=='live' and d['passed'] is True and d['authored_eligible']==32 and len(d['families_complete'])>=15 and d['input_cap']==1024 and d['context_freeze_sha256']==r.identity(ns/'context-freeze.json'),'Actual fresh pilot pass required')
    release=r.read(private/'w03h-inputs'/pkg/'heldout-release.json')
    verify_path=private/'w03h-inputs'/pkg/'pilot-independent.json';check=r.read(verify_path)
    r.require(release['schema']=='W03H-heldout-release-v1' and release['package_sha256']==pkg and release['released'] is True and release['runtime_ready'] is True and release['pilot_decision_sha256']==r.identity(ns/'pilot-decision.json') and release['independent_sha256']==r.identity(verify_path) and release['reviewer'].strip() and release['reference'].strip(),'Independent central heldout release required')
    r.require(check['schema']=='W03H-independent-v1' and check['scope']=='live' and check['passed'] is True and check['pilot_decision_sha256']==r.identity(ns/'pilot-decision.json') and check['package_sha256']==pkg,'Independent script reconstruction required')
    mandatory={'release.json','study-bindings.json','plan.json','cap.json','context-observations.json','context-decisions.json','context-freeze.json','pilot-decision.json','inputs/pilot.json','inputs/heldout.json','inputs/PROTOCOL.md'}
    r.require(mandatory<=set(check['files']) and check['files']['release.json']==r.identity(ns/'release.json'),'Independent mandatory artifact identities required')
    for name,h in check['files'].items():r.require(r.identity(ns/name)==h,'Pilot changed after independent reconstruction')
    heldout=private/'w03h-results'/pkg/'heldout'
    if (heldout/'heldout-release.json').exists():r.require(r.read(heldout/'heldout-release.json')==release,'Heldout release changed after lock')
    return release

def observations(ns,cache,cohort):
    tok=cache['tokenizer'];rows={}
    for f in r.FRAME.values():
        if cohort=='pilot':
            for b in r.POL:
                obs=r.pilot.measure(tok,r.messages(f,b));rows[f['id']+'--authored--'+b]=dict(family=f['id'],writer='authored',branch=b,criteria=f['branches'][b],observation=obs,error=obs.get('error'))
        for w in ARMS:
            row=r.slot_record(ns,'writers--'+f['id']+'--'+w)
            for b in r.POL:
                obs=row.get('contexts',{}).get(b,{})
                error=None if row.get('status')=='ok' and row.get('decoded') else 'writer '+row.get('status','unstarted')
                rows['writers--'+'--'.join([f['id'],w,b])]=dict(family=f['id'],writer=w,branch=b,criteria=f['branches'][b],observation=obs,error=error)
                print(json.dumps(dict(measured='--'.join([f['id'],w,b]),input_tokens=(obs.get('prompt') or {}).get('input_tokens'),error=error),ensure_ascii=False),flush=True)
    r.save(ns,'context-observations.json',rows)
    return dict(contexts=len(rows),input_cap=1024)

def attached_worker(job):
    private=Path(job['private']);ns,_,_,_=bind(private,job['package'],job['cohort'])
    import conversation_environment as env
    evidence={}
    with ancestors.local_history(private,HERE.parent/'verified-parents'):
        old,adopted=env.worker_admission(job,evidence,True)
    b=r.pilot.P['toolchain']
    r.require(evidence['environment_signature']==b['environment_signature'] and evidence['hardware_signature']==b['hardware_signature'] and evidence['versions']==b['baseline_distributions'] and r.identity(adopted['calibration']/'vectors.pt')==b['vector_sha256'] and old['calibration_checkpoint']==b['checkpoint_sha256'],'Pinned runtime, model or vector drift')
    sys.path.insert(0,str(adopted['root']/'src'))
    cache={'admission':(evidence,old,adopted)}
    from followup_transport import preclaim
    if job['stage']=='measure':
        r.save(ns/'attempts'/job['attempt'],'admitted.json',evidence)
        from transformers import AutoTokenizer
        tok=AutoTokenizer.from_pretrained(b['model'],revision=b['model_revision'],trust_remote_code=False,local_files_only=True)
        tok.padding_side='left'
        r.require(tok.chat_template,'Frozen tokenizer has no template')
        cache['tokenizer']=tok
        return observations(ns,cache,job['cohort'])
    return r.worker(job,cache,lambda e:print('W03R_EVENT '+json.dumps(e,ensure_ascii=False),flush=True),preclaim)

def dispatch(private,ns,job):
    import conversation_environment as env
    from w03h_transport import stream_controller
    # No detached process: both attached pipes stay owned by the visible notebook.
    ancestors.mirror(private,HERE.parent/'verified-parents')
    attempt=uuid4().hex;folder=ns/'attempts'/attempt;folder.mkdir(parents=True)
    report={}
    with ancestors.local_history(private,HERE.parent/'verified-parents'):
        _,_,prefix,environ,snapshot=env.prepare(private,r.read(HERE/'w01_conversation_v1.json'),report,True)
    r.save(folder,'restore.json',report)
    request=dict(job,namespace=str(ns),attempt=attempt,start=time.time(),snapshot=str(snapshot),phase=job['stage'])
    r.save(folder,'request.json',request)
    def relay(nonce):
        challenge=dict(slot='attached-worker',nonce=nonce)
        print('W03R_PRECLAIM '+json.dumps(challenge),flush=True)
        reply=sys.stdin.readline()
        r.require(reply and json.loads(reply)==challenge,'Notebook attachment lost');return nonce
    try:
        stream_controller([str(prefix/'bin/python'),'-I','-B','-u',str(HERE/'w03h_run.py'),'worker',str(folder/'request.json'),str(folder/'result.json')],relay,environ=environ)
        return r.checked(folder,'result.json')
    except BaseException as exc:
        r.save(ns,'stops/'+attempt+'.json',dict(attempt=attempt,reason=str(exc),utc=r.utc()));raise

def execute(job):
    private=Path(job['private']);pkg=job['package'];cohort=job['cohort'];stage=job['stage']
    r.require(cohort in COHORTS,'Choose pilot or heldout')
    ns,folder,release,families=bind(private,pkg,cohort)
    if stage=='admit':
        if cohort=='heldout':transition(private,pkg)
        return dict(stage='CANDIDATE W03H admission',cohort=cohort,families=len(families[cohort]),cap=1024,forwards=0,ancestry=r.pilot_run.admit(private),offline=r.pilot_run.offline_inputs(private))
    if stage=='recover' and not any(job.get(k) for k in ('takeover','disposition','repair')):return dict(**r.recover(ns),lease=return_archive.lease_info(ns/'lease.json'),stops=r.pending_stops(ns))
    ns.mkdir(parents=True,exist_ok=True);lease=ns/'lease.json';owner=uuid4().hex
    if stage=='recover' and job.get('takeover'):
        r.require(return_archive.lease_info(lease)['owner']==job['takeover'],'Wrong former lease owner');r.save(ns,'past-leases/'+r.identity(lease)+'.raw',lease.read_bytes());lease.unlink()
    r.publish_claim(lease,dict(owner=owner,stage=stage,utc=r.utc()))
    try:
        if stage=='lock':
            if cohort=='heldout':r.save(ns,'heldout-release.json',transition(private,pkg))
            r.save(ns,'release.json',release)
            for name in release['files']:r.save(ns,'inputs/'+name,(folder/name).read_bytes())
            r.save(ns,'plan.json',slots(families[cohort],cohort));r.save(ns,'cap.json',dict(common_input_tokens=1024,scope='live'))
            if not (ns/'seed.json').exists():r.save(ns,'seed.json',dict(seed=os.urandom(32).hex(),key='complete answer card canonical content; sorted hash(seed + encoded content)',purpose='10 percent of concordant unique answer cards rounded up'))
            names=['release.json','plan.json','cap.json','seed.json',*['inputs/'+n for n in release['files']]]
            if cohort=='heldout':names.append('heldout-release.json')
            r.save(ns,'study-bindings.json',{n:r.identity(ns/n) for n in names});return dict(reserved=len(slots(families[cohort],cohort)))
        r.checked(ns,'study-bindings.json')
        if 'upload_bytes' in job:
            import base64
            raw=base64.b64decode(job['upload_bytes'],validate=True)
            r.require(r.sha(raw)==job['upload_sha256'] and json.loads(raw)==job['upload'],'Original review bytes differ')
            r.save(ns,'review-originals/'+stage+'/'+job['upload_sha256']+'.json',raw)
            r.save(ns,'review-originals/'+stage+'/receipt.json',dict(sha256=job['upload_sha256'],path=job['upload_path']))
        if stage in ('context_reader1','context_reader2','context_adjudicator','reader1','reader2','adjudicator'):
            r.require('upload_bytes' in job,'Exact original review return and sender hash required')
        if stage=='recover':return r.recover(ns,job.get('disposition'),repair=bool(job.get('repair')))
        if stage=='clear_stop':r.clear_stops(ns,job['stops'],job['reference'],job['diagnosis']);return dict(cleared=True)
        if stage in ('writers','crossed','measure'):
            r.require(not r.pending_stops(ns) and not r.recover(ns)['outstanding'],'Resolve technical stops and claims first')
            r.require(job['reference'].strip() and job['credit'].strip(),'Current execution/resource reference required')
            if cohort=='heldout':transition(private,pkg)
            if stage=='crossed':r.require(cohort=='heldout','No pilot responder generations');context.verify(ns)
            if stage=='measure':r.checked(ns,'writers-closed.json')
            else:r.require(type(job['limit']) is int and 1<=job['limit']<=(48 if cohort=='pilot' else 24 if stage=='writers' else 144),'Invalid bounded block')
            return dispatch(private,ns,dict(job,owner=owner))
        if stage in ('close_writers','close_crossed'):return dict(closed=r.close_phase(ns,stage.removeprefix('close_'),job['status']))
        if stage=='context_issue':context.issue(ns);return dict(forms=[str(ns/'context'/ (n+'-template.json')) for n in ('reader1','reader2')])
        if stage.startswith('context_') and stage.removeprefix('context_') in ('reader1','reader2','adjudicator'):
            role=stage.removeprefix('context_');context.submit(ns,role,job['upload']);return dict(accepted=role)
        if stage=='context_disputes':context.disputes(ns);return dict(forms=[str(ns/'context/adjudicator-template.json')])
        if stage=='context_freeze':context.freeze(ns,job['reference']);return dict(context_freeze=r.identity(ns/'context-freeze.json'))
        if stage=='pilot_decision':r.require(cohort=='pilot','Wrong cohort');return pilot_decision(ns)
        if stage=='answer_issue':context.verify(ns);reviews.export(ns,'crossed');return dict(forms=[str(ns/reviews.path('crossed',n+'-template')) for n in ('reader1','reader2')])
        if stage in ('reader1','reader2','adjudicator'):
            ids={r.checked(ns,'context/'+n+'.json')['reviewer'].strip().casefold() for n in ('reader1','reader2','adjudicator') if (ns/('context/'+n+'.json')).exists()}
            r.require(job['upload']['reviewer'].strip().casefold() not in ids,'Separate answer readers required');reviews.submit(ns,'crossed',stage,job['upload']);return dict(accepted=stage)
        if stage=='disputes':reviews.disputes(ns,'crossed');return dict(forms=[str(ns/reviews.path('crossed','adjudicator-template'))])
        if stage=='labels':reviews.freeze(ns,'crossed',job['reference']);return dict(labels=r.identity(ns/reviews.path('crossed','labels')))
        if stage=='final':
            import w03h_report
            return dict(html=str(w03h_report.publish(ns,cohort)),archive=return_archive.archive(ns))
        if stage=='export':return dict(archive=return_archive.archive(ns))
        raise ValueError('Unknown W03H stage')
    finally:
        if return_archive.lease_info(lease) and return_archive.lease_info(lease)['owner']==owner:lease.unlink()
if __name__=='__main__':
    import signal
    def interrupted(signum,frame):raise InterruptedError('Attached controller interrupted')
    signal.signal(signal.SIGTERM,interrupted)
    mode,request,result=sys.argv[1:]
    job=r.read(Path(request))
    value=attached_worker(job) if mode=='worker' else execute(job)
    r.st.atomic(Path(result),value)
