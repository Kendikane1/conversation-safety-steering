"""Visible notebook entry: one explicitly selected stage, exact-byte imports."""
from pathlib import Path
import base64,hashlib,json,sys,tempfile
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from w03h_transport import stream_controller

def action(stage,cohort,private,package):
    from google.colab import output
    from IPython.display import HTML,display
    def ask(prompt):
        value=input(prompt+' ').strip()
        if not value:raise ValueError('Stopped before action: value required')
        return value
    job=dict(stage=stage,cohort=cohort,private=str(private),package=package)
    if stage in ('writers','crossed','measure'):
        job.update(reference=ask('Central execution reference?'),credit=ask('Current GPU/time/credit observation?'))
        if stage!='measure':job['limit']=int(ask('Maximum new claims in this attached block (pilot writers48; heldout writers24; responders144)?'))
    if stage.startswith('close_'):job['status']=ask('Close phase as complete or stopped?')
    if stage in ('context_reader1','context_reader2','context_adjudicator','reader1','reader2','adjudicator'):
        name=input('Exact private Drive return path; Enter only if this review is unavailable: ').strip()
        if not name:
            print('No review imported. Closure retains missing judgments as uncertain.',flush=True)
            return dict(imported=False,reason='Unavailable return; no votes invented')
        path=Path(name);expected=ask('Sender-verified SHA-256 of the exact return?')
        if not path.is_relative_to(private) or path.resolve()!=path:raise ValueError('Return must be an ordinary file under private Drive')
        raw=path.read_bytes();actual=hashlib.sha256(raw).hexdigest()
        if actual!=expected:raise ValueError('Review SHA-256 differs')
        job.update(upload=json.loads(raw),upload_bytes=base64.b64encode(raw).decode(),upload_sha256=actual,upload_path=str(path))
    if stage in ('context_freeze','labels'):job['reference']=ask('Central masked review closure reference?')
    if stage=='recover':
        command=input('Enter to inspect, or repair/dispose after old controller has stopped: ').strip()
        if command not in ('','repair','dispose'):raise ValueError('Unknown recovery action')
        if command:
            job['repair']=True;job['takeover']=input('Former lease owner only after all old processes stop; otherwise Enter: ').strip()
            if command=='dispose':job['disposition']=[ask('Exact consumed slot key?'),ask('Permanent unknown-consumption reason?')]
    if stage=='clear_stop':
        path=Path(ask('Exact current stop-clearance JSON path?'));data=json.loads(path.read_bytes())
        job.update(stops=data['stops'],reference=ask('Central clearance reference?'),diagnosis=data['diagnosis'])
    with tempfile.TemporaryDirectory() as tmp:
        request=Path(tmp)/'request.json';answer=Path(tmp)/'answer.json';request.write_text(json.dumps(job))
        stream_controller([sys.executable,'-I','-B','-u',str(HERE/'w03h_run.py'),'controller',str(request),str(answer)],lambda nonce:output.eval_js(json.dumps(nonce),timeout_sec=20))
        result=json.loads(answer.read_bytes())
    for name in result.get('forms',[]):
        p=Path(name);print('Private masked form',p,hashlib.sha256(p.read_bytes()).hexdigest(),flush=True)
    if result.get('html'):display(HTML(Path(result['html']).read_text()))
    print(json.dumps(result,indent=2,ensure_ascii=False),flush=True)
    print('SAVE this executed notebook, reopen the saved stage output, and retain the private artifacts before advancing.',flush=True)
    return result
